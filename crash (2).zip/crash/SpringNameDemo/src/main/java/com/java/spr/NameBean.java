package com.java.spr;

public interface NameBean {
	String fullName();
}
