export class Menu {
    public menId : number;
    public menItem : string;
    public menPrice : number;
    public menCalories : number;
    public menSpeciality : string;
}
