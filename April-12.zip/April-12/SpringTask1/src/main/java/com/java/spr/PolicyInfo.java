package com.java.spr;

public class PolicyInfo {

	private String policyName;
	private String agentName;
	private String payMode;
	private double premium;
	
	// Create 3 beans as beanPolcicyPension, beanPolicyRetirement, beanPolicyMoneyback
	// Paymode is Quarterly/HalfYearly/Yearly
	
}
