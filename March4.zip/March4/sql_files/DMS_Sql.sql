Use practice930;

delete from Employ;

Insert into Employ(Empno, Name, Gender, Dept, Desig, Basic) 
values(1,'Sampath','MALE','Java','Programmer',88422),
	  (2,'Satish','MALE','React','Expert',88211),
      (3, 'Adi Lakshmi','FEMALE','Spring','Expert',77244),
      (4, 'Megha', 'FEMALE', 'Dotnet', 'Manager', 88233),
      (5, 'Tarak','Male','Java','Programmer',88233);
      
select * from Employ;