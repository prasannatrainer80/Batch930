export class Student {
    public sid : number;
    public sname : string;
    public grade : string;
    public cgp : number;
    public status : boolean;
}
