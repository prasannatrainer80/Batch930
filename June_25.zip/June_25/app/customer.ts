export class Customer {
    public custId : number;
    public custName : string;
    public city : string;
    public state : string;
    public bilAmount : number;
}
