package com.java.spr;

public interface ComplaintDao {
	String addComplaint(Complaint complaint);
}
