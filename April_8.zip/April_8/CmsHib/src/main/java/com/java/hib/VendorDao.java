package com.java.hib;

import java.util.List;

public interface VendorDao {

	List<Vendor> showVendors();
}
