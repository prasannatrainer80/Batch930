package com.java.spr;

public interface Hello {

	String greeting(String name);
}
