export class User {
    public id : number;
    public name : string;
    public username :string;
    public phone : string;
    public email : string;
    public website : string;
}
