import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  standalone: true,
  imports: [],
  template: `
    <p>
      first works!
    </p>
    <p>
      This is my First Ang 16/17 component
    </p>
  `,
  styleUrl: './first.component.css'
})
export class FirstComponent {

}
