import { Component } from '@angular/core';

@Component({
  selector: 'app-dos-dashboard',
  templateUrl: './dos-dashboard.component.html',
  styleUrls: ['./dos-dashboard.component.scss']
})
export class DosDashboardComponent {

}
