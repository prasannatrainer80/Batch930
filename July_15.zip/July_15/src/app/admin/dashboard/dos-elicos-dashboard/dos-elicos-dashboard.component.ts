import { Component } from '@angular/core';

@Component({
  selector: 'app-dos-elicos-dashboard',
  templateUrl: './dos-elicos-dashboard.component.html',
  styleUrls: ['./dos-elicos-dashboard.component.scss']
})
export class DosElicosDashboardComponent {

}
