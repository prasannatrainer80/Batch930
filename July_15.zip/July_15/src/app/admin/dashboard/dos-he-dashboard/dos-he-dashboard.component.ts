import { Component } from '@angular/core';

@Component({
  selector: 'app-dos-he-dashboard',
  templateUrl: './dos-he-dashboard.component.html',
  styleUrls: ['./dos-he-dashboard.component.scss']
})
export class DosHeDashboardComponent {

}
