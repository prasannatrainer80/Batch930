import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-admin-dashboard',
  templateUrl: './sub-admin-dashboard.component.html',
  styleUrls: ['./sub-admin-dashboard.component.scss']
})
export class SubAdminDashboardComponent {

}
