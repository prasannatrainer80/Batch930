import { Component } from '@angular/core';

@Component({
  selector: 'app-it-dashboard',
  templateUrl: './it-dashboard.component.html',
  styleUrls: ['./it-dashboard.component.scss']
})
export class ItDashboardComponent {

}
