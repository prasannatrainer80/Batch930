import { Component } from '@angular/core';

@Component({
  selector: 'app-offer-dashboard',
  templateUrl: './offer-dashboard.component.html',
  styleUrls: ['./offer-dashboard.component.scss']
})
export class OfferDashboardComponent {

}
