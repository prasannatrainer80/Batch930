import { MasterBase } from '../master-base'

export class URL extends MasterBase<string> {
  override controlType = 'url';
}