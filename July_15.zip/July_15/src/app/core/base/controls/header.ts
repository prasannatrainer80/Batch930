import { MasterBase } from '../master-base'

export class Header extends MasterBase<string> {
  override controlType = 'header';
}