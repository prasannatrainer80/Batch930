import { MasterBase } from '../master-base'

export class CourseTypes extends MasterBase<string> {
    override controlType = 'coursetype';
}