import { MasterBase } from '../master-base'

export class Checkbox extends MasterBase<string> {
  override controlType = 'checkbox';
}