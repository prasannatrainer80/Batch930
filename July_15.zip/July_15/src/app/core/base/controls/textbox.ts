import { MasterBase } from '../master-base'

export class Textbox extends MasterBase<string> {
  override controlType = 'textbox';
}