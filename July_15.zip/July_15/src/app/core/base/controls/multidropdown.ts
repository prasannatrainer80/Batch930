import { MasterBase } from '../master-base'

export class MultiDropdown extends MasterBase<string> {
  override controlType = 'multidropdown';
}