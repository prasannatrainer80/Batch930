import { MasterBase } from '../master-base'

export class LabelValue extends MasterBase<string> {
  override controlType = 'labelvalue';
}