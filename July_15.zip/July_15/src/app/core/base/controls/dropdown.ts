import { MasterBase } from '../master-base'

export class Dropdown extends MasterBase<string> {
  override controlType = 'dropdown';
}