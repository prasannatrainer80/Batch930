export class Permission {
    view!: string;
    add!: string;
    edit!: string;
    remove!: string;
  }
  