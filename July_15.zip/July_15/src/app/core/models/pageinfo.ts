export interface PageInfo {
    offset: number;
    pageSize: number;
    limit: number;
    count: number;
}