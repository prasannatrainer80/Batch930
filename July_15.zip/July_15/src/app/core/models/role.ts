export enum Role {
  Platform = '1',
  Admin = '2',
  Faculty = '3',
  Agent = '4',
  Student = '5',
}
