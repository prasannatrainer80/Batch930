export class User {
  clientId!: string;
  campusId!: string;
  roleId!: string;
  roleType!: string;
  roleName!: string;
  loginId!: string;
  userId!: string;
  userName!: string;
  reqKey!: string;
  reqToken!: string;
  lastLogin!: string;
  jwt!: string;
  roleList!: any;
}
