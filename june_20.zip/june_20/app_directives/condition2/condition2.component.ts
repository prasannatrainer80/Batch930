import { Component } from '@angular/core';

@Component({
  selector: 'app-condition2',
  templateUrl: './condition2.component.html',
  styleUrl: './condition2.component.css'
})
export class Condition2Component {
  no : number;
}
